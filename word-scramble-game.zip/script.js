const words = ["apple", "banana", "orange", "grapes", "lemon"];
let currentWord = "";
let scrambledWord = "";

function scramble(word) {
  return word.split("").sort(() => Math.random() - 0.5).join("");
}

function setNewWord() {
  currentWord = words[Math.floor(Math.random() * words.length)];
  scrambledWord = scramble(currentWord);
  document.getElementById("scrambled-word").textContent = scrambledWord;
}

function checkAnswer() {
  const userInput = document.getElementById("user-input").value.toLowerCase();
  const message = document.getElementById("message");

  if (userInput === currentWord) {
    message.textContent = "✅ Correct!";
    message.style.color = "lightgreen";
    setTimeout(() => {
      setNewWord();
      document.getElementById("user-input").value = "";
      message.textContent = "";
    }, 1500);
  } else {
    message.textContent = "❌ Try Again!";
    message.style.color = "red";
  }
}

window.onload = setNewWord;
